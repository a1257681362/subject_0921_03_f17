package com.evops.config;

import org.flywaydb.core.Flyway;
import org.flywaydb.core.api.MigrationInfo;
import org.flywaydb.core.api.MigrationType;
import org.junit.jupiter.api.Test;
import org.springframework.core.io.ClassPathResource;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.jdbc.datasource.init.ScriptUtils;

import javax.sql.DataSource;
import java.sql.Connection;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Flyway 接管方案关键场景验证：
 * 1) 新环境：空库 V1->V2 一键建到最新，结构与台账齐全；
 * 2) 旧环境：先执行手工时代 schema.sql（模拟现场库），再 baseline-on-migrate ——
 *    V1 只记基线不重放，V2 增量执行，原有数据与台账不动；
 * 3) 重复启动：二次 migrate 无待执行版本，幂等无副作用。
 */
class FlywayMigrationTest {

    private DataSource newMemDb(String name) {
        DriverManagerDataSource ds = new DriverManagerDataSource();
        ds.setDriverClassName("org.h2.Driver");
        ds.setUrl("jdbc:h2:mem:" + name + ";DB_CLOSE_DELAY=-1;MODE=MySQL");
        ds.setUsername("sa");
        return ds;
    }

    /**
     * Flyway 在 H2 MySQL 模式下把历史表建成带引号小写名（flyway_schema_history），
     * 默认模式下为大写；从元数据取真实存储名并加引号引用，两种模式通用。
     */
    private String quotedTable(JdbcTemplate jdbc, String logicalName) {
        String actual = jdbc.queryForObject(
                "SELECT TABLE_NAME FROM INFORMATION_SCHEMA.TABLES WHERE LOWER(TABLE_NAME) = ?",
                String.class, logicalName.toLowerCase());
        assertNotNull(actual, "表不存在：" + logicalName);
        return "\"" + actual + "\"";
    }

    private Flyway flyway(DataSource ds) {
        return Flyway.configure()
                .dataSource(ds)
                .locations("classpath:db/migration")
                .baselineOnMigrate(true)
                .baselineVersion("1")
                .load();
    }

    @Test
    void freshDatabase_buildsToLatestInOneShot() {
        DataSource ds = newMemDb("flyway-fresh");
        Flyway flyway = flyway(ds);
        flyway.migrate();

        JdbcTemplate jdbc = new JdbcTemplate(ds);
        // 全部业务表落地（H2 MySQL 模式下标识符存小写，用 LOWER 比较以兼容两种模式）
        for (String table : new String[]{
                "t_seat", "t_show_session", "t_sale_order", "t_ticket",
                "t_session_seat_occupy", "t_ticket_status_flow", "t_ticket_no_alloc",
                "t_idempotent_request", "t_admin_user", "t_refresh_token",
                "t_token_blacklist", "t_checkin_appointment",
                "t_agent_message", "t_agent_parse_error",
                "t_ticket_attachment",
                "t_notify_template", "t_notify_recipient",
                "t_notify_dispatch", "t_notify_record", "t_inbox_message",
                "t_evops_schema_version", "flyway_schema_history"}) {
            Integer c = jdbc.queryForObject(
                    "SELECT COUNT(*) FROM INFORMATION_SCHEMA.TABLES WHERE LOWER(TABLE_NAME) = ?",
                    Integer.class, table);
            assertNotNull(c);
            assertEquals(1, c, "新库应一键建出表：" + table);
        }

        // history：V1/V2 均为成功的 SQL 迁移（测试库为 H2 MySQL 模式，
        // Flyway 的历史表/列均为带引号小写名）
        String historyTable = quotedTable(jdbc, "flyway_schema_history");
        List<String> versions = jdbc.queryForList(
                "SELECT \"version\" FROM " + historyTable
                        + " WHERE \"version\" IS NOT NULL AND \"success\" = TRUE "
                        + "ORDER BY \"installed_rank\"",
                String.class);
        assertEquals(java.util.Arrays.asList("1", "2", "3", "4"), versions);

        // V2 物理对象真实存在
        Integer idx = jdbc.queryForObject(
                "SELECT COUNT(*) FROM INFORMATION_SCHEMA.INDEXES WHERE LOWER(INDEX_NAME) = 'idx_t_refresh_expires'",
                Integer.class);
        assertEquals(1, idx);

        // V3 物理对象真实存在
        Integer idxV3 = jdbc.queryForObject(
                "SELECT COUNT(*) FROM INFORMATION_SCHEMA.INDEXES WHERE LOWER(INDEX_NAME) = 'idx_t_attach_ticket'",
                Integer.class);
        assertEquals(1, idxV3);

        // V4 物理对象真实存在
        for (String idxV4 : new String[]{"idx_notify_tpl_event", "idx_notify_rec_retry", "idx_inbox_staff"}) {
            Integer c = jdbc.queryForObject(
                    "SELECT COUNT(*) FROM INFORMATION_SCHEMA.INDEXES WHERE LOWER(INDEX_NAME) = ?",
                    Integer.class, idxV4);
            assertEquals(1, c, "V4 索引应存在：" + idxV4);
        }

        // 旧台账：V1 的 5 个历史标记 + V2/V3/V4 双写
        List<String> ledger = jdbc.queryForList(
                "SELECT version_no FROM t_evops_schema_version ORDER BY id", String.class);
        assertTrue(ledger.containsAll(java.util.Arrays.asList(
                "base-0", "ticket-1", "auth-1", "checkin-1", "agent-1",
                "flyway-2", "flyway-3", "flyway-4")));

        // 二次启动：无待执行版本
        MigrationInfo[] pending = flyway.info().pending();
        assertEquals(0, pending.length);
    }

    @Test
    void legacyDatabase_baselinesAtV1AndAppliesOnlyV2() throws Exception {
        DataSource ds = newMemDb("flyway-legacy");
        // 模拟现场旧库：手工执行接管前的 schema.sql
        try (Connection conn = ds.getConnection()) {
            ScriptUtils.executeSqlScript(conn, new ClassPathResource("schema.sql"));
        }
        JdbcTemplate jdbc = new JdbcTemplate(ds);
        // 接管前不存在 flyway 表，旧台账 5 个历史标记
        Integer flywayTableBefore = jdbc.queryForObject(
                "SELECT COUNT(*) FROM INFORMATION_SCHEMA.TABLES WHERE LOWER(TABLE_NAME) = 'flyway_schema_history'",
                Integer.class);
        assertEquals(0, flywayTableBefore);
        Integer ledgerBefore = jdbc.queryForObject(
                "SELECT COUNT(*) FROM t_evops_schema_version", Integer.class);
        assertEquals(5, ledgerBefore);
        // V2 索引接管前不存在
        Integer idxBefore = jdbc.queryForObject(
                "SELECT COUNT(*) FROM INFORMATION_SCHEMA.INDEXES WHERE LOWER(INDEX_NAME) = 'idx_t_refresh_expires'",
                Integer.class);
        assertEquals(0, idxBefore);

        // 首飞：V1 记基线，只执行 V2
        Flyway flyway = flyway(ds);
        flyway.migrate();

        // V1 行为类型 BASELINE（不是重放 SQL），V2 为 SQL
        String historyTable = quotedTable(jdbc, "flyway_schema_history");
        String v1Type = jdbc.queryForObject(
                "SELECT \"type\" FROM " + historyTable + " WHERE \"version\" = '1'", String.class);
        assertEquals(MigrationType.BASELINE.name(), v1Type);
        String v2Type = jdbc.queryForObject(
                "SELECT \"type\" FROM " + historyTable + " WHERE \"version\" = '2'", String.class);
        assertEquals(MigrationType.SQL.name(), v2Type);
        Boolean v2Success = jdbc.queryForObject(
                "SELECT \"success\" FROM " + historyTable + " WHERE \"version\" = '2'", Boolean.class);
        assertTrue(v2Success);

        // V2/V3/V4 增量落地；旧台账保留 5 条并新增双写 3 条
        Integer idxAfter = jdbc.queryForObject(
                "SELECT COUNT(*) FROM INFORMATION_SCHEMA.INDEXES WHERE LOWER(INDEX_NAME) = 'idx_t_refresh_expires'",
                Integer.class);
        assertEquals(1, idxAfter);
        List<String> ledger = jdbc.queryForList(
                "SELECT version_no FROM t_evops_schema_version", String.class);
        assertEquals(8, ledger.size());
        assertTrue(ledger.contains("flyway-2"));
        assertTrue(ledger.contains("flyway-3"));
        assertTrue(ledger.contains("flyway-4"));
        assertTrue(ledger.containsAll(java.util.Arrays.asList(
                "base-0", "ticket-1", "auth-1", "checkin-1", "agent-1")));

        // 再次启动幂等
        flyway.migrate();
        assertEquals(0, flyway.info().pending().length);
        Integer ledgerFinal = jdbc.queryForObject(
                "SELECT COUNT(*) FROM t_evops_schema_version", Integer.class);
        assertEquals(8, ledgerFinal);
    }

    @Test
    void repeatMigrate_isIdempotent() {
        DataSource ds = newMemDb("flyway-repeat");
        Flyway flyway = flyway(ds);
        flyway.migrate();
        flyway.migrate();
        assertEquals(0, flyway.migrate().migrationsExecuted);
    }
}

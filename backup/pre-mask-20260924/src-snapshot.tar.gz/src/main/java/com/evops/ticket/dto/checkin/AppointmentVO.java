package com.evops.ticket.dto.checkin;

import lombok.Data;

import java.time.LocalDateTime;

/**
 * 检票排期预约视图。
 */
@Data
public class AppointmentVO {
    private Long id;
    private String appointmentNo;
    private Long seatId;
    private String venue;
    private String area;
    private String rowNo;
    private String seatNo;
    private String visitorName;
    private String contact;
    private LocalDateTime startTime;
    private LocalDateTime endTime;
    private String status;
    private String cancelReason;
    private String operator;
    private String requestId;
    private LocalDateTime bizTime;
    private Integer version;
    private LocalDateTime createTime;
    private LocalDateTime updateTime;
}

package com.evops.auth.security;

/**
 * 访问令牌校验后的声明快照。
 */
public class JwtClaims {
    private long userId;
    private String username;
    /** 签发时的密码（令牌）版本；与库内不一致即判失效 */
    private int tokenVersion;
    /** 令牌唯一标识，登出/改密按此拉黑 */
    private String jti;
    private long exp;

    public long getUserId() { return userId; }
    public void setUserId(long userId) { this.userId = userId; }
    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; }
    public int getTokenVersion() { return tokenVersion; }
    public void setTokenVersion(int tokenVersion) { this.tokenVersion = tokenVersion; }
    public String getJti() { return jti; }
    public void setJti(String jti) { this.jti = jti; }
    public long getExp() { return exp; }
    public void setExp(long exp) { this.exp = exp; }
}

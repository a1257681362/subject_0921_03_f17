package com.evops.auth.service;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.evops.auth.config.AuthProperties;
import com.evops.auth.dto.AdminProfileVO;
import com.evops.auth.dto.TokenPairVO;
import com.evops.auth.entity.AdminUser;
import com.evops.auth.entity.RefreshToken;
import com.evops.auth.entity.TokenBlacklist;
import com.evops.auth.mapper.AdminUserMapper;
import com.evops.auth.mapper.RefreshTokenMapper;
import com.evops.auth.mapper.TokenBlacklistMapper;
import com.evops.auth.security.JwtClaims;
import com.evops.auth.security.PasswordHasher;
import com.evops.auth.security.TokenGenerator;
import com.evops.auth.web.AuthException;
import com.evops.auth.security.JwtService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionDefinition;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.support.TransactionTemplate;

import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;

/**
 * 双令牌认证核心。
 *
 * 安全约定（内部审计整改 auth-1）：
 * 1. 访问令牌短有效期（15min），吊销靠黑名单 + token_version 双通道；
 * 2. 刷新令牌只在响应里出现一次明文，库存 SHA-256；
 * 3. 刷新一次性：消费即 USED，旧令牌立刻失效，新令牌沿同家族轮换；
 * 4. 已 USED/REVOKED 的令牌再次使用 = 疑似泄露，同家族 ACTIVE 令牌全部连坐撤销；
 * 5. 登出拉黑当前访问令牌（并撤销本设备刷新令牌）；
 * 6. 改密：token_version 自增使全体旧访问令牌失效、撤销全部刷新令牌、拉黑当前访问令牌——全端下线。
 */
@Service
public class AuthService {

    private static final Logger log = LoggerFactory.getLogger(AuthService.class);

    private final AdminUserMapper userMapper;
    private final RefreshTokenMapper refreshMapper;
    private final TokenBlacklistMapper blacklistMapper;
    private final PasswordHasher passwordHasher;
    private final TokenGenerator tokenGenerator;
    private final JwtService jwtService;
    private final AuthProperties props;
    /** 安全撤销必须独立落库：即使外层刷新事务因抛 401 回滚，连坐撤销也不能回滚掉 */
    private final TransactionTemplate requiresNewTx;

    public AuthService(AdminUserMapper userMapper, RefreshTokenMapper refreshMapper,
                       TokenBlacklistMapper blacklistMapper, PasswordHasher passwordHasher,
                       TokenGenerator tokenGenerator, JwtService jwtService, AuthProperties props,
                       PlatformTransactionManager transactionManager) {
        this.userMapper = userMapper;
        this.refreshMapper = refreshMapper;
        this.blacklistMapper = blacklistMapper;
        this.passwordHasher = passwordHasher;
        this.tokenGenerator = tokenGenerator;
        this.jwtService = jwtService;
        this.props = props;
        this.requiresNewTx = new TransactionTemplate(transactionManager);
        this.requiresNewTx.setPropagationBehavior(TransactionDefinition.PROPAGATION_REQUIRES_NEW);
    }

    // ==================== 登录 ====================

    public TokenPairVO login(String username, String password) {
        LambdaQueryWrapper<AdminUser> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(AdminUser::getUsername, username);
        AdminUser user = userMapper.selectOne(wrapper);
        // 用户名不存在与密码错误统一文案，防止账号探测
        if (user == null || !passwordHasher.matches(password, user.getPasswordHash())) {
            throw AuthException.unauthorized("用户名或密码错误");
        }
        if (!"ACTIVE".equals(user.getStatus())) {
            throw AuthException.unauthorized("账号已停用，请联系管理员");
        }
        // 每次登录开一条新的设备家族
        return issuePair(user, tokenGenerator.randomId());
    }

    // ==================== 刷新（一次性轮换 + 重放连坐） ====================

    @Transactional(rollbackFor = Exception.class)
    public TokenPairVO refresh(String rawRefreshToken) {
        String tokenHash = tokenGenerator.sha256Hex(rawRefreshToken);
        RefreshToken row = refreshMapper.selectOne(new LambdaQueryWrapper<RefreshToken>()
                .eq(RefreshToken::getTokenHash, tokenHash));
        if (row == null) {
            throw AuthException.unauthorized("刷新令牌无效，请重新登录");
        }
        if (row.getExpiresAt().isBefore(LocalDateTime.now())) {
            throw AuthException.unauthorized("刷新令牌已过期，请重新登录");
        }

        AdminUser user = userMapper.selectById(row.getUserId());
        if (user == null || !"ACTIVE".equals(user.getStatus())) {
            throw AuthException.unauthorized("账号不可用，请重新登录");
        }
        if (user.getTokenVersion() == null || !user.getTokenVersion().equals(row.getTokenVersion())) {
            // 改密后旧家族签发的刷新令牌整体作废；独立事务提交，不随本次 401 回滚
            LocalDateTime revokeTime = LocalDateTime.now();
            String familyId = row.getFamilyId();
            requiresNewTx.executeWithoutResult(s ->
                    refreshMapper.revokeFamilyActive(familyId, revokeTime));
            throw AuthException.unauthorized("登录态已失效，请重新登录");
        }

        LocalDateTime now = LocalDateTime.now();
        int consumed = refreshMapper.consume(tokenHash, now);
        if (consumed == 0) {
            // 令牌已被消费或撤销却再次出现：重放。按家族连坐并记录安全事件。
            // 撤销走独立事务：必须先落库，再抛 401，避免随外层事务回滚导致连坐失效
            String currentStatus = row.getStatus();
            String familyId = row.getFamilyId();
            Integer revoked = requiresNewTx.execute(s ->
                    refreshMapper.revokeFamilyActive(familyId, now));
            log.warn("刷新令牌重放，疑似泄露：userId={}, familyId={}, rowStatus={}, 连坐撤销{}枚",
                    row.getUserId(), familyId, currentStatus, revoked);
            throw AuthException.unauthorized("刷新令牌已失效，请重新登录");
        }

        // 旧令牌已 USED 立即失效；新令牌沿同家族签发，构成轮换链
        return issuePair(user, row.getFamilyId());
    }

    // ==================== 登出 ====================

    @Transactional(rollbackFor = Exception.class)
    public void logout(JwtClaims access, String rawRefreshToken) {
        blacklistAccess(access, TokenBlacklist.REASON_LOGOUT);

        if (rawRefreshToken != null && !rawRefreshToken.trim().isEmpty()) {
            RefreshToken row = refreshMapper.selectOne(new LambdaQueryWrapper<RefreshToken>()
                    .eq(RefreshToken::getTokenHash, tokenGenerator.sha256Hex(rawRefreshToken.trim())));
            // 只允许撤销本人令牌；非 ACTIVE 行幂等跳过
            if (row != null && row.getUserId() == access.getUserId()) {
                refreshMapper.revokeById(row.getId(), LocalDateTime.now());
            }
        }
    }

    // ==================== 改密（全端下线） ====================

    @Transactional(rollbackFor = Exception.class)
    public AdminProfileVO changePassword(JwtClaims access, String oldPassword, String newPassword) {
        AdminUser user = userMapper.selectById(access.getUserId());
        if (user == null) {
            throw AuthException.unauthorized("账号不存在");
        }
        if (!passwordHasher.matches(oldPassword, user.getPasswordHash())) {
            throw AuthException.badRequest("原密码不正确");
        }
        if (passwordHasher.matches(newPassword, user.getPasswordHash())) {
            throw AuthException.badRequest("新密码不能与原密码相同");
        }

        // 1) 改密并推进令牌版本——所有旧 tv 的访问令牌立即不被信任
        user.setPasswordHash(passwordHasher.hash(newPassword));
        user.setTokenVersion(user.getTokenVersion() == null ? 1 : user.getTokenVersion() + 1);
        user.setUpdateTime(LocalDateTime.now());
        int rows = userMapper.updateById(user);
        if (rows == 0) {
            throw new IllegalStateException("账号更新失败，请重试");
        }

        // 2) 撤销全部设备的在用刷新令牌
        int revoked = refreshMapper.revokeUserActive(user.getId(), LocalDateTime.now());

        // 3) 当前这枚访问令牌也立刻拉黑（其它设备的访问令牌由 tv 不匹配拦截，无需逐枚落黑名单）
        blacklistAccess(access, TokenBlacklist.REASON_PASSWORD_CHANGE);

        log.warn("改密完成，全端下线：userId={}, 撤销刷新令牌{}枚", user.getId(), revoked);
        return toProfile(user);
    }

    // ==================== 访问令牌校验（过滤器调用） ====================

    /**
     * 校验访问令牌：签名/有效期 -> 未拉黑 -> 账号有效且 tv 匹配。任一不过抛 401。
     */
    public JwtClaims authenticate(String accessToken) {
        JwtClaims claims = jwtService.verify(accessToken);

        TokenBlacklist blocked = blacklistMapper.selectById(claims.getJti());
        if (blocked != null) {
            throw AuthException.unauthorized("登录态已失效，请重新登录");
        }

        AdminUser user = userMapper.selectById(claims.getUserId());
        if (user == null || !"ACTIVE".equals(user.getStatus())) {
            throw AuthException.unauthorized("账号不可用，请重新登录");
        }
        if (user.getTokenVersion() == null || user.getTokenVersion() != claims.getTokenVersion()) {
            throw AuthException.unauthorized("登录态已失效，请重新登录");
        }
        return claims;
    }

    // ==================== 内部 ====================

    private TokenPairVO issuePair(AdminUser user, String familyId) {
        int tv = user.getTokenVersion() == null ? 0 : user.getTokenVersion();
        String jti = tokenGenerator.randomId();
        String accessToken = jwtService.issueAccess(user.getId(), user.getUsername(), tv, jti);

        String rawRefresh = tokenGenerator.randomToken();
        RefreshToken record = new RefreshToken();
        record.setTokenHash(tokenGenerator.sha256Hex(rawRefresh));
        record.setUserId(user.getId());
        record.setFamilyId(familyId);
        record.setTokenVersion(tv);
        record.setStatus(RefreshToken.ACTIVE);
        record.setExpiresAt(LocalDateTime.now().plusSeconds(props.getRefreshTokenTtlSeconds()));
        refreshMapper.insert(record);

        TokenPairVO vo = new TokenPairVO();
        vo.setAccessToken(accessToken);
        vo.setRefreshToken(rawRefresh);
        vo.setTokenType("Bearer");
        vo.setAccessTokenExpiresIn(props.getAccessTokenTtlSeconds());
        vo.setRefreshTokenExpiresIn(props.getRefreshTokenTtlSeconds());
        vo.setUser(toProfile(user));
        return vo;
    }

    private void blacklistAccess(JwtClaims access, String reason) {
        TokenBlacklist row = new TokenBlacklist();
        row.setJti(access.getJti());
        row.setUserId(access.getUserId());
        row.setReason(reason);
        row.setExpiresAt(LocalDateTime.ofInstant(
                Instant.ofEpochSecond(access.getExp()), ZoneId.systemDefault()));
        try {
            blacklistMapper.insert(row);
        } catch (DuplicateKeyException ignored) {
            // 重复登出幂等
        }
    }

    private AdminProfileVO toProfile(AdminUser user) {
        AdminProfileVO vo = new AdminProfileVO();
        vo.setId(user.getId());
        vo.setUsername(user.getUsername());
        vo.setDisplayName(user.getDisplayName());
        vo.setVenue(user.getVenue());
        vo.setRole(user.getRole());
        return vo;
    }

    /** 供 /me 查询当前账号信息。 */
    public AdminProfileVO profile(long userId) {
        AdminUser user = userMapper.selectById(userId);
        if (user == null) {
            throw AuthException.unauthorized("账号不存在");
        }
        return toProfile(user);
    }
}

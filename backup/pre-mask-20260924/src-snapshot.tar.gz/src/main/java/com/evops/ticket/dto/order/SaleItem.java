package com.evops.ticket.dto.order;

import lombok.Data;

import javax.validation.constraints.NotNull;
import java.math.BigDecimal;

@Data
public class SaleItem {
    @NotNull(message = "座位ID不能为空")
    private Long seatId;

    private BigDecimal price;
}

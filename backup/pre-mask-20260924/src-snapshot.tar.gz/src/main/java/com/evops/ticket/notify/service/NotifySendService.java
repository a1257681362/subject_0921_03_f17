package com.evops.ticket.notify.service;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.evops.ticket.entity.SaleOrder;
import com.evops.ticket.entity.Seat;
import com.evops.ticket.entity.ShowSession;
import com.evops.ticket.entity.Ticket;
import com.evops.ticket.mapper.SaleOrderMapper;
import com.evops.ticket.mapper.SeatMapper;
import com.evops.ticket.mapper.ShowSessionMapper;
import com.evops.ticket.mapper.TicketMapper;
import com.evops.ticket.notify.channel.ChannelSendResult;
import com.evops.ticket.notify.channel.NotifyChannelSender;
import com.evops.ticket.notify.config.NotifyProperties;
import com.evops.ticket.notify.entity.NotifyDispatch;
import com.evops.ticket.notify.entity.NotifyRecord;
import com.evops.ticket.notify.entity.NotifyRecipient;
import com.evops.ticket.notify.entity.NotifyTemplate;
import com.evops.ticket.notify.enums.DispatchStatus;
import com.evops.ticket.notify.enums.NotifyChannel;
import com.evops.ticket.notify.enums.NotifyEventCode;
import com.evops.ticket.notify.enums.RecordStatus;
import com.evops.ticket.notify.mapper.NotifyRecipientMapper;
import com.evops.ticket.notify.mapper.NotifyTemplateMapper;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * 检票通知发送编排。
 *
 * <p>流程：检票事务提交后触发 -> 二次加工票/订单/场次/座位为模板变量 ->
 * 取启用模板与场务收件人 -> 逐「通道 × 收件人」渲染并快照 -> 建批次与发送记录 ->
 * 站内信/邮件双通道立即投递；失败退避重试 2 次（定时任务捞 RETRYING 续投），耗尽置 FAILED。
 *
 * <p>批次按 (eventCode, ticketId) 唯一，事件重复投递不会重复通知。
 * 渲染标题/正文/变量集逐记录快照：模板后续改版只升 tpl_version，已发内容原样不变。
 */
@Service
public class NotifySendService {

    private static final Logger log = LoggerFactory.getLogger(NotifySendService.class);

    private final NotifyProperties properties;
    private final NotifyStore store;
    private final NotifyTemplateMapper templateMapper;
    private final NotifyRecipientMapper recipientMapper;
    private final TicketMapper ticketMapper;
    private final SaleOrderMapper orderMapper;
    private final ShowSessionMapper sessionMapper;
    private final SeatMapper seatMapper;
    private final ObjectMapper objectMapper;

    /** channel -> sender。不在构造期固化（发送器可能被测试替身替换），每次按 channel() 现取。 */
    private final List<NotifyChannelSender> senderList;

    public NotifySendService(NotifyProperties properties, NotifyStore store,
                             NotifyTemplateMapper templateMapper, NotifyRecipientMapper recipientMapper,
                             TicketMapper ticketMapper, SaleOrderMapper orderMapper,
                             ShowSessionMapper sessionMapper, SeatMapper seatMapper,
                             ObjectMapper objectMapper, List<NotifyChannelSender> senderList) {
        this.properties = properties;
        this.store = store;
        this.templateMapper = templateMapper;
        this.recipientMapper = recipientMapper;
        this.ticketMapper = ticketMapper;
        this.orderMapper = orderMapper;
        this.sessionMapper = sessionMapper;
        this.seatMapper = seatMapper;
        this.objectMapper = objectMapper;
        this.senderList = senderList;
    }

    /** 检票事件入口：幂等（同票同事件只通知一次）。任何异常不外溢影响主流程。 */
    public void onTicketCheck(Long ticketId, String operator, String requestId, String reason) {
        if (!properties.isEnabled()) {
            log.debug("检票通知总开关关闭，跳过 ticketId={}", ticketId);
            return;
        }
        try {
            trigger(ticketId, operator, requestId, reason);
        } catch (Exception e) {
            // 通知失败绝不反噬票务主流程（主事务此时已提交）；落库/投递失败均有记录与重试兜底
            log.error("检票通知触发失败 ticketId={}", ticketId, e);
        }
    }

    private void trigger(Long ticketId, String operator, String requestId, String reason) {
        Ticket ticket = ticketMapper.selectById(ticketId);
        if (ticket == null) {
            log.warn("检票通知找不到票，跳过 ticketId={}", ticketId);
            return;
        }
        SaleOrder order = orderMapper.selectById(ticket.getOrderId());
        ShowSession session = sessionMapper.selectById(ticket.getSessionId());
        Seat seat = seatMapper.selectById(ticket.getSeatId());
        LocalDateTime eventTime = ticket.getBizTime() != null ? ticket.getBizTime() : LocalDateTime.now();
        Map<String, String> vars = NotifyVarsBuilder.build(ticket, order, session, seat, operator, reason, eventTime);

        List<NotifyTemplate> templates = activeTemplates(NotifyEventCode.TICKET_CHECK.code());
        List<NotifyRecipient> recipients = activeRecipients();
        if (templates.isEmpty()) {
            log.warn("检票通知未配置启用模板，事件 {} 无通道可发 ticketNo={}",
                    NotifyEventCode.TICKET_CHECK.code(), ticket.getTicketNo());
            return;
        }
        if (recipients.isEmpty()) {
            log.warn("检票通知无启用场务收件人，ticketNo={}", ticket.getTicketNo());
            return;
        }

        NotifyDispatch dispatch = new NotifyDispatch();
        dispatch.setEventCode(NotifyEventCode.TICKET_CHECK.code());
        dispatch.setTicketId(ticketId);
        dispatch.setTicketNo(ticket.getTicketNo());
        dispatch.setOrderNo(order == null ? null : order.getOrderNo());
        dispatch.setSessionCode(session == null ? null : session.getSessionCode());
        dispatch.setStatus(RecordStatus.PENDING.name());
        dispatch.setTotalChannels(0);
        dispatch.setSuccessChannels(0);
        dispatch.setFailChannels(0);
        dispatch.setTriggerOperator(operator);
        dispatch.setRequestId(requestId);
        dispatch.setEventTime(eventTime);
        try {
            store.insertDispatch(dispatch);
        } catch (DuplicateKeyException e) {
            // 事件重复消费（如重放/补发）：已通知过，直接忽略
            log.info("检票通知批次已存在，跳过重复触发 ticketId={}", ticketId);
            return;
        }

        String varsJson = toJson(vars);
        List<NotifyRecord> records = new ArrayList<>();
        for (NotifyChannel channel : NotifyChannel.values()) {
            NotifyTemplate template = templateOf(templates, channel);
            if (template == null || !channelSwitchOn(channel)) {
                // 该通道未配模板或被开关关闭：整条通道不参与
                continue;
            }
            for (NotifyRecipient recipient : recipients) {
                NotifyRecord record = buildRecord(dispatch, template, recipient, channel,
                        ticket, order, session, vars, varsJson, operator, requestId, eventTime);
                store.insertRecord(record);
                records.add(record);
                if (RecordStatus.SKIPPED.name().equals(record.getStatus())) {
                    continue;
                }
                dispatch(record);
            }
        }

        refreshDispatchSummary(dispatch.getId());
        log.info("检票通知批次完成 dispatchId={} ticketNo={} 记录 {} 条",
                dispatch.getId(), ticket.getTicketNo(), records.size());
    }

    /** 定时任务：扫描到期 RETRYING 记录续投，并刷新所属批次汇总。 */
    public int retryDue() {
        if (!properties.isEnabled()) {
            return 0;
        }
        List<NotifyRecord> due = store.dueRetry(properties.getRetryBatchSize());
        java.util.Set<Long> dispatchIds = new java.util.HashSet<>();
        for (NotifyRecord record : due) {
            try {
                dispatch(record);
                if (record.getDispatchId() != null) {
                    dispatchIds.add(record.getDispatchId());
                }
            } catch (Exception e) {
                log.error("检票通知重试异常 recordId={}", record.getId(), e);
            }
        }
        for (Long dispatchId : dispatchIds) {
            refreshDispatchSummary(dispatchId);
        }
        return due.size();
    }

    /** 人工重发：FAILED/RETRYING 记录立即再投一次（至少一次语义，邮件可能产生一封重复，属预期）。 */
    public NotifyRecord manualRetry(Long recordId) {
        NotifyRecord record = store.getRecord(recordId);
        if (record == null) {
            throw new IllegalArgumentException("发送记录不存在：id=" + recordId);
        }
        if (RecordStatus.SUCCESS.name().equals(record.getStatus())) {
            throw new IllegalArgumentException("已发送成功的记录无需重发");
        }
        if (RecordStatus.SKIPPED.name().equals(record.getStatus())) {
            throw new IllegalArgumentException("跳过发送的记录（收件人无该通道地址）不能重发，请先补全收件人");
        }
        dispatch(record);
        refreshDispatchSummary(record.getDispatchId());
        return store.getRecord(recordId);
    }

    /**
     * 实际投递并据结果更新记录状态。首发与重试共用。
     * 无事务：网络调用不持库连接；状态更新走 store 的独立事务。
     */
    public void dispatch(NotifyRecord record) {
        NotifyChannelSender sender = resolveSender(record.getChannel());
        if (sender == null) {
            store.updateResult(record.getId(), RecordStatus.FAILED.name(), null, null,
                    nz(record.getRetryCount()), null, "未找到通道发送器：" + record.getChannel(), false);
            return;
        }
        ChannelSendResult result = sender.send(record);
        if (result.isSuccess()) {
            store.updateResult(record.getId(), RecordStatus.SUCCESS.name(), result.getHttpStatus(),
                    result.getMessageId(), nz(record.getRetryCount()), null, null, true);
            return;
        }
        scheduleRetry(record, result.getHttpStatus(), result.getError());
    }

    private void scheduleRetry(NotifyRecord row, Integer httpStatus, String error) {
        int attempt = nz(row.getRetryCount()) + 1;
        if (attempt > properties.getMaxRetry()) {
            store.updateResult(row.getId(), RecordStatus.FAILED.name(), httpStatus, null,
                    attempt - 1, null, abbreviate(error), false);
            log.error("检票通知重试 {} 次耗尽置 FAILED recordId={} channel={} ticketNo={} 最后错误={}",
                    properties.getMaxRetry(), row.getId(), row.getChannel(), row.getTicketNo(), abbreviate(error));
            return;
        }
        LocalDateTime nextTime = LocalDateTime.now().plusSeconds(properties.backoffSeconds(attempt));
        store.updateResult(row.getId(), RecordStatus.RETRYING.name(), httpStatus, null,
                attempt, nextTime, abbreviate(error), false);
        log.warn("检票通知投递失败，第 {} 次重试排期 recordId={} at={} err={}",
                attempt, row.getId(), nextTime, abbreviate(error));
    }

    /**
     * 按记录重算批次汇总：全部通道成功 SUCCESS / 成败并存 PARTIAL / 全失败 FAILED；
     * 仍有 RETRYING 时按当前所见结果给 PARTIAL/FAILED，重试任务完成后再次刷新。
     */
    private void refreshDispatchSummary(Long dispatchId) {
        List<NotifyRecord> records = store.listByDispatch(dispatchId);
        // 通道 -> 该通道记录状态集合
        Map<String, List<String>> byChannel = new LinkedHashMap<>();
        for (NotifyRecord r : records) {
            byChannel.computeIfAbsent(r.getChannel(), k -> new ArrayList<>()).add(r.getStatus());
        }
        int planned = byChannel.size();
        int success = 0;
        int fail = 0;
        int skipped = 0;
        boolean pending = false;
        for (List<String> statuses : byChannel.values()) {
            boolean hasUnfinished = statuses.stream().anyMatch(
                    s -> RecordStatus.PENDING.name().equals(s) || RecordStatus.RETRYING.name().equals(s));
            boolean hasFailed = statuses.contains(RecordStatus.FAILED.name());
            boolean hasSuccess = statuses.contains(RecordStatus.SUCCESS.name());
            boolean allSkipped = statuses.stream().allMatch(s -> RecordStatus.SKIPPED.name().equals(s));
            if (hasUnfinished) {
                pending = true;
            }
            if (hasFailed) {
                fail++;
            } else if (hasSuccess && !hasUnfinished) {
                success++;
            } else if (allSkipped) {
                // 该通道收件人都不具备条件（如全员无邮箱）：不计失败，单独记跳过
                skipped++;
            }
        }
        String status;
        if (pending && success == 0 && fail == 0) {
            status = RecordStatus.RETRYING.name();
        } else if (fail == 0 && !pending && success > 0) {
            // 有通道成功、其余仅跳过（无失败）：按成功计；全部通道都跳过说明配置有误，落 FAILED 暴露问题
            status = DispatchStatus.SUCCESS.name();
        } else if (fail == 0 && !pending && success == 0 && skipped > 0) {
            status = DispatchStatus.FAILED.name();
        } else if (success > 0 || skipped > 0) {
            status = DispatchStatus.PARTIAL.name();
        } else {
            status = DispatchStatus.FAILED.name();
        }
        store.updateDispatchSummary(dispatchId, status, success, fail, planned);
    }

    // ==================== 组装 ====================

    private NotifyChannelSender resolveSender(String channel) {
        for (NotifyChannelSender sender : senderList) {
            if (channel.equals(sender.channel())) {
                return sender;
            }
        }
        return null;
    }

    private NotifyRecord buildRecord(NotifyDispatch dispatch, NotifyTemplate template,
                                     NotifyRecipient recipient, NotifyChannel channel,
                                     Ticket ticket, SaleOrder order, ShowSession session,
                                     Map<String, String> vars, String varsJson,
                                     String operator, String requestId, LocalDateTime eventTime) {
        String title = TemplateRenderer.render(template.getTitleTemplate(), vars);
        String content = TemplateRenderer.render(template.getBodyTemplate(), vars);

        NotifyRecord record = new NotifyRecord();
        record.setDispatchId(dispatch.getId());
        record.setEventCode(NotifyEventCode.TICKET_CHECK.code());
        record.setChannel(channel.name());
        record.setTemplateId(template.getId());
        record.setTemplateVersion(template.getTemplateVersion() == null ? 1 : template.getTemplateVersion());
        record.setRecipientId(recipient.getId());
        record.setRecipientName(recipient.getRecipientName());
        record.setTicketNo(ticket.getTicketNo());
        record.setOrderNo(order == null ? null : order.getOrderNo());
        record.setSessionCode(session == null ? null : session.getSessionCode());
        record.setTitleRendered(title);
        record.setContentRendered(content);
        record.setVarsSnapshot(varsJson);
        record.setStatus(RecordStatus.PENDING.name());
        record.setRetryCount(0);
        record.setMaxRetry(properties.getMaxRetry());
        record.setOperator(operator);
        record.setRequestId(requestId);
        record.setBizTime(eventTime);

        String address;
        if (channel == NotifyChannel.INBOX) {
            address = recipient.getStaffNo();
        } else {
            address = recipient.getEmail();
        }
        record.setRecipientAddress(address);
        if (address == null || address.trim().isEmpty()) {
            // 收件人不具备该通道条件：记 SKIPPED 可查，不投递不计成败
            record.setStatus(RecordStatus.SKIPPED.name());
            record.setLastError(channel == NotifyChannel.INBOX
                    ? "收件人无工号，无法投递站内信" : "收件人无邮箱，无法投递邮件");
        }
        return record;
    }

    private List<NotifyTemplate> activeTemplates(String eventCode) {
        return templateMapper.selectList(new LambdaQueryWrapper<NotifyTemplate>()
                .eq(NotifyTemplate::getEventCode, eventCode)
                .eq(NotifyTemplate::getEnabled, 1)
                .eq(NotifyTemplate::getStatus, "ACTIVE")
                .orderByAsc(NotifyTemplate::getId));
    }

    private List<NotifyRecipient> activeRecipients() {
        return recipientMapper.selectList(new LambdaQueryWrapper<NotifyRecipient>()
                .eq(NotifyRecipient::getEnabled, 1)
                .eq(NotifyRecipient::getStatus, "ACTIVE")
                .orderByAsc(NotifyRecipient::getId));
    }

    private NotifyTemplate templateOf(List<NotifyTemplate> templates, NotifyChannel channel) {
        for (NotifyTemplate template : templates) {
            if (channel.name().equals(template.getChannel())) {
                return template;
            }
        }
        return null;
    }

    private boolean channelSwitchOn(NotifyChannel channel) {
        if (channel == NotifyChannel.INBOX) {
            return properties.isInboxEnabled();
        }
        if (channel == NotifyChannel.EMAIL) {
            return properties.isEmailEnabled();
        }
        return false;
    }

    private String toJson(Map<String, String> vars) {
        try {
            return objectMapper.writeValueAsString(vars);
        } catch (Exception e) {
            return "{}";
        }
    }

    private static int nz(Integer value) {
        return value == null ? 0 : value;
    }

    private static String abbreviate(String text) {
        if (text == null) {
            return null;
        }
        return text.length() > 1900 ? text.substring(0, 1900) : text;
    }
}

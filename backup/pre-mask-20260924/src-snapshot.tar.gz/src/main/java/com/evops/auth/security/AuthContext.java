package com.evops.auth.security;

/**
 * 已认证访问令牌对应的当前登录态（请求级 ThreadLocal）。
 */
public final class AuthContext {
    private static final ThreadLocal<CurrentUser> HOLDER = new ThreadLocal<>();

    private AuthContext() {
    }

    public static void set(CurrentUser user) {
        HOLDER.set(user);
    }

    public static CurrentUser get() {
        return HOLDER.get();
    }

    public static void clear() {
        HOLDER.remove();
    }

    public static long requireUserId() {
        CurrentUser u = HOLDER.get();
        if (u == null) {
            throw new IllegalStateException("当前请求无登录态");
        }
        return u.getUserId();
    }

    public static class CurrentUser {
        private final long userId;
        private final String username;
        private final String jti;
        private final long accessExpEpochSecond;

        public CurrentUser(long userId, String username, String jti, long accessExpEpochSecond) {
            this.userId = userId;
            this.username = username;
            this.jti = jti;
            this.accessExpEpochSecond = accessExpEpochSecond;
        }

        public long getUserId() { return userId; }
        public String getUsername() { return username; }
        public String getJti() { return jti; }
        public long getAccessExpEpochSecond() { return accessExpEpochSecond; }
    }
}

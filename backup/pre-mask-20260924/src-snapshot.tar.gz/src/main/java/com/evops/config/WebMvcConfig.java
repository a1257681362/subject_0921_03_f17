package com.evops.config;

import com.evops.auth.service.AuthService;
import com.evops.auth.web.JwtAuthInterceptor;
import com.evops.common.web.RequestContextInterceptor;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
public class WebMvcConfig implements WebMvcConfigurer {

    private final AuthService authService;
    private final ObjectMapper objectMapper;

    public WebMvcConfig(AuthService authService, ObjectMapper objectMapper) {
        this.authService = authService;
        this.objectMapper = objectMapper;
    }

    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        // 先认证后取业务上下文：RequestContextInterceptor 需要读取 AuthContext 绑定操作人
        registry.addInterceptor(new JwtAuthInterceptor(authService, objectMapper))
                .addPathPatterns(
                        "/api/ticket/**",
                        "/api/admin/**",
                        "/api/auth/logout",
                        "/api/auth/change-password",
                        "/api/auth/me")
                .order(0);

        registry.addInterceptor(new RequestContextInterceptor())
                .addPathPatterns("/api/**")
                .order(1);
    }
}

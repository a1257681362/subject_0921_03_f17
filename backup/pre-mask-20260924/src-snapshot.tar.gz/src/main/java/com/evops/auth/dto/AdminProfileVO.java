package com.evops.auth.dto;

import lombok.Data;

@Data
public class AdminProfileVO {
    private Long id;
    private String username;
    private String displayName;
    private String venue;
    private String role;
}

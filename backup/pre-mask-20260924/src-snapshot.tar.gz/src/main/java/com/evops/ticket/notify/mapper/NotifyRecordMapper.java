package com.evops.ticket.notify.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.evops.ticket.notify.dto.stats.ChannelStatRow;
import com.evops.ticket.notify.entity.NotifyRecord;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.time.LocalDateTime;
import java.util.List;

public interface NotifyRecordMapper extends BaseMapper<NotifyRecord> {

    /**
     * 扫描到期可重发记录：RETRYING 且退避到点（首发在事件线程内同步完成，不落 PENDING 等待）。
     */
    @Select("SELECT * FROM t_notify_record WHERE status = 'RETRYING' " +
            "AND next_retry_time IS NOT NULL AND next_retry_time <= #{now} " +
            "ORDER BY id LIMIT #{limit}")
    List<NotifyRecord> selectDueRetry(@Param("now") LocalDateTime now, @Param("limit") int limit);

    /**
     * 按通道分组统计发送结果（可选时间范围/事件码过滤）。SKIPPED 不计入投递成败，单独一列。
     */
    @Select("<script>" +
            "SELECT channel, status, COUNT(*) AS cnt FROM t_notify_record " +
            "<where>" +
            "  <if test='eventCode != null'> AND event_code = #{eventCode}</if>" +
            "  <if test='from != null'> AND create_time &gt;= #{from}</if>" +
            "  <if test='to != null'> AND create_time &lt; #{to}</if>" +
            "</where>" +
            "GROUP BY channel, status ORDER BY channel, status" +
            "</script>")
    List<ChannelStatRow> selectStats(@Param("eventCode") String eventCode,
                                     @Param("from") LocalDateTime from,
                                     @Param("to") LocalDateTime to);
}

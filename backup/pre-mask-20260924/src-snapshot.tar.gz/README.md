# EVOPS 基础工作区

这是 springboot的骨架项目。

技术栈：Java 8、Spring Boot 2.7、MyBatis-Plus、H2 本地文件数据库、Shiro、Thymeleaf。

> 内部审计整改（auth-1）：场馆后台登录已改为 **JWT 双令牌**，Shiro 表单登录不再用于 `/api/**`。

启动前准备：

1. 执行 `mvn -q -DskipTests compile` 验证骨架构建。
2. 执行 `mvn spring-boot:run` 启动应用；**Flyway 在启动时自动按版本执行 `src/main/resources/db/migration/V*.sql`**（详见下文「Schema 变更管理」）。
3. H2 数据文件默认写入工作区 `data/evops`。如需修改路径，编辑 `application.yml` 中的 `jdbc:h2:file:` 连接串。

## Schema 变更管理（Flyway，2026-09 接管）

表结构不再靠各环境手工执行 SQL，统一由 Flyway 管版本：

- 脚本目录 `src/main/resources/db/migration`，命名 `V<版本号>__<描述>.sql`，启动时按版本号顺序自动执行，结果记入 `flyway_schema_history`（变更历史随时可查：`SELECT version,description,type,success,installed_on FROM flyway_schema_history`）。
- **新环境**：空库从 `V1__baseline_schema.sql`（现有全量快照）起顺序执行到最新版本，一键建到最新。
- **现有环境（旧库）**：配置了 `baseline-on-migrate: true` + `baseline-version: 1`，首次启动把 V1 记为基线（不重放全量脚本、不动存量数据），只执行基线之后的增量；之后各环境版本保持一致。
- 已执行的版本脚本**禁止修改**（启动校验会拦）；任何变更只能新增 `V<n+1>__xxx.sql`。
- 当前版本：V1 基线（base/ticket/auth/checkin/agent 全部现有表）、V2（`t_refresh_token.expires_at` 夜间清理索引）、V3（演出票附件 `t_ticket_attachment` 元数据表与按票号索引）。

**新旧逻辑并跑与切旧（观察期两天）**：接管初期保留旧的 `schema.sql`（语句全部幂等，结构已在则空跑），与 Flyway 同时工作；每个 Flyway 增量向旧台账 `t_evops_schema_version` 双写一行 `flyway-n`。每次启动 `SchemaHistoryReconciler` 自动核对两套台账（基线标记、逐版本双写、增量物理对象），一致时打印「Schema 台账对账一致」，不一致打 ERROR（`evops.schema.fail-on-mismatch=true` 可强卡启动）。两天数字对得上后，将 `spring.sql.init.mode` 置 `never`（环境变量 `SPRING_SQL_INIT_MODE=never`）即完成切旧；稳定后可关闭对账（`evops.schema.reconcile-enabled=false`）。

> `..\..\docs\schema\evops.sql` 交付副本现对应 `db/migration/V1__baseline_schema.sql` 的基线快照，后续增量以 `V*.sql` 为准。

## 场馆票务底账（ticket-1）

统一前缀 `/api/ticket`，返回结构统一为 `ApiResponse { success, message, data }`。

- 写请求请求头：`X-Operator-Id`（操作人，缺省 system）、`X-Request-Id`（请求号，写接口必传，作为幂等键；同号重复请求返回首次结果快照）。
- 写请求体可带 `bizTime`（业务时间，缺省取服务器时间）；每条业务记录均落库 operator / requestId / bizTime / version。

| 方法 | 路径 | 说明 |
|---|---|---|
| POST | `/api/ticket/seats` | 座位建档（场馆/区域/排/座号） |
| GET | `/api/ticket/seats`、`/api/ticket/seats/{id}` | 座位分页/详情 |
| DELETE | `/api/ticket/seats/{id}` | 座位删除（只打逻辑删除标记，可按同位置重建） |
| POST | `/api/ticket/sessions` | 演出场次建档（sessionCode 为票号短码） |
| GET | `/api/ticket/sessions`、`/api/ticket/sessions/{id}` | 场次分页/详情 |
| POST | `/api/ticket/orders` | 售票单+票明细建档（主从同事务，不允许半截落库） |
| GET | `/api/ticket/orders/{id}` | 售票单详情（含票列表） |
| POST | `/api/ticket/orders/{id}/void` | 整单作废（反向记录，占用全部释放） |
| GET | `/api/ticket/tickets/{ticketNo}` | 按票号检索（含场次、座位、追溯流水） |
| GET | `/api/ticket/tickets?ticketNo=&sessionId=&status=&orderNo=` | 票分页检索 |
| POST | `/api/ticket/tickets/{ticketNo}/check` | 检票 SOLD→CHECKED |
| POST | `/api/ticket/tickets/{ticketNo}/refund` | 退票 SOLD→REFUNDED，释放座次 |
| POST | `/api/ticket/tickets/{ticketNo}/void` | 作废 SOLD/CHECKED→VOID，释放座次 |

要点：

- 同一座位按场次独立售卖：有效占用唯一约束在 `t_session_seat_occupy(session_id, seat_id)`；退票/作废物理删除占用行即释放，可同场次再售；历史票与流水原样保留。
- 作废/退票走 `t_ticket_status_flow` 反向记录（reverse_flag=1，origin_record_id 指向 ISSUE 流水），构成追溯链。
- 票状态机：SOLD→CHECKED（检票）、SOLD→REFUNDED（退票）、SOLD/CHECKED→VOID（作废）；非法流转返回 success=false。
- 票号系统生成：`T + 场次短码 + 10 位顺序号`，每场次计数行加锁分配，票号全局唯一。
- 并发控制：状态/主数据更新走 version 乐观锁；5 路同 requestId 并发只落 1 条记录、6 路抢同一座位恰好 1 单成功。

## 检票排期自动化（checkin-1）

把检票安排从人肉拼图改为区间排期。预约按**半开区间** `[startTime, endTime)` 存储，同一座位：

- **区间重叠即冲突**；
- **相邻预约首尾间隔不足 20 分钟也冲突**（边界恰好 20 分钟放行）；
- **取消即释放**：置 CANCELLED 后该区间立即不再参与冲突，可马上再约（历史行保留追溯）；
- 可查询每个座位在任意区间内的有效占用；
- 冲突时响应体直接带回撞上的预约与**推荐空档**，场务可改约。

并发写先对座位行 `SELECT … FOR UPDATE` 加锁按座位串行：5 路并发抢同一座位同一时段恰好 1 条成功；不同座位互不阻塞。写接口沿用 `X-Operator-Id` / `X-Request-Id` / `bizTime` 与幂等模板，**不改动既有票务契约**，仅新增端点（前缀 `/api/ticket/checkin`）。冲突不走 HTTP 错误码：`200 + success=false`，`data` 为冲突详情。

| 方法 | 路径 | 说明 |
|---|---|---|
| POST | `/api/ticket/checkin/appointments` | 预约检票档口（seatId/startTime/endTime，visitorName/contact 可选） |
| POST | `/api/ticket/checkin/appointments/{id}/cancel` | 取消预约，立即释放，可再约（body 可选 reason/bizTime） |
| GET | `/api/ticket/checkin/appointments/{id}` | 预约详情 |
| GET | `/api/ticket/checkin/appointments` | 预约明细分页（seatId/status/from/to 可选） |
| GET | `/api/ticket/checkin/seats/{seatId}/occupancy?start=&end=` | 查询某座位区间内的有效占用 |
| GET | `/api/ticket/checkin/seats/{seatId}/free-slots?wantedStart=&wantedEnd=&durationMinutes=` | 空档推荐（3 天窗口、就近返回最多 5 个，时长缺省取目标区间） |

冲突响应示例（`success=false`，data 摘要）：

```json
{
  "success": false,
  "message": "该座位所选时段已被预约或与相邻预约间隔不足20分钟",
  "data": {
    "seatId": 1, "bufferMinutes": 20,
    "requestedStart": "2026-09-25T10:15:00", "requestedEnd": "2026-09-25T10:45:00",
    "conflicts": [ { "id": 1, "startTime": "2026-09-25T10:00:00", "endTime": "2026-09-25T10:30:00" } ],
    "suggestedSlots": [
      { "startTime": "2026-09-25T10:50:00", "endTime": "2026-09-25T11:20:00" }
    ]
  }
}
```

要点：

- 数据落 `t_checkin_appointment`，状态 `ACTIVE/CANCELLED`；预约号 `APT + 时间戳 + 4 位随机`，与审计字段（operator/requestId/bizTime/version）口径一致。
- 冲突判定为纯区间运算：既有 `[a,b)` 与新约 `[s,e)` 冲突当且仅当 `s < b+20m 且 a < e+20m`（半开区间，端点相接不算重叠）。
- 对外契约零改动，联调由场务牵头按上表端点确认。

## 代理售票平台 XML 报文对接（agent-1）

场务多次提出、此前卡在平台排期的代理售票平台对接，按平台只认 XML 报文的约束落实。用 **Jackson XML（jackson-dataformat-xml + Woodstox）** 做对象 ⇄ 报文双向映射，字段命名与层级严格按平台规范；**收发原文一律留档、按票号归档可回查**；出站失败**指数退避自动重试**；入站坏报文/不合规/业务失败**进异常清单**。

### 报文规范

根元素带平台命名空间 `http://schema.evops.com/ticket/v1`，UTF-8 编码、带 XML 声明；时间统一 `yyyy-MM-dd HH:mm:ss`（入站兼容 ISO-8601）。

```xml
<?xml version="1.0" encoding="UTF-8"?>
<agentMessage xmlns="http://schema.evops.com/ticket/v1">
  <header>
    <messageId>MSG20260923193000A1B2C3D4</messageId>
    <messageType>TICKET_ISSUE</messageType>   <!-- TICKET_ISSUE/CHECK/REFUND/VOID -->
    <timestamp>2026-09-23 19:30:00</timestamp>
    <source>VENUE</source><target>AGENT</target>
  </header>
  <body>
    <ticket>
      <ticketNo>TSH002000000001</ticketNo>
      <orderNo>SO20260923190000A1B2</orderNo>
      <status>SOLD</status>
      <price>180.00</price>
      <operator>box_office01</operator>
      <bizTime>2026-09-23 19:30:00</bizTime>
      <session><showName>天鹅湖·芭蕾经典</showName><sessionCode>SH002</sessionCode>
               <showTime>2026-10-01 19:30:00</showTime><venue>滨江大剧院</venue></session>
      <seat><area>一层池座</area><rowNo>A</rowNo><seatNo>08</seatNo>
    </ticket>
  </body>
</agentMessage>
```

平台应答为 `<agentAck>`：`result.code` 取 `SUCCESS / DUPLICATE / REJECTED`，`correlationId` 回填原报文 `messageId`。

### 端点

| 方向 | 方法 | 路径 | 访问 | 说明 |
|---|---|---|---|---|
| 入站 | POST | `/api/agent/v1/messages` | 匿名（平台服务器直投） | 收 `application/xml`，回 ACK XML；HTTP 恒 200，结果看 ACK code |
| 管理 | GET | `/api/ticket/agent/messages` | 访问令牌 | 报文分页（direction/messageType/status/ticketNo 过滤） |
| 管理 | GET | `/api/ticket/agent/messages/{id}` | 访问令牌 | 报文详情（含收发原文） |
| 管理 | GET | `/api/ticket/agent/tickets/{ticketNo}/messages` | 访问令牌 | **按票号归档回查**：该票全部收发报文原文 |
| 管理 | POST | `/api/ticket/agent/messages/{id}/retry` | 访问令牌 | 手动重发失败/待发出站报文（原 messageId，平台幂等） |
| 管理 | POST | `/api/ticket/agent/tickets/{ticketNo}/push` | 访问令牌 | 按票补推（依票当前状态生成新报文，新 messageId） |
| 管理 | GET | `/api/ticket/agent/errors` | 访问令牌 | 异常清单分页（默认只看 OPEN，可按 errorType/ticketNo 过滤） |
| 管理 | GET | `/api/ticket/agent/errors/{id}`、`/errors/{id}/payload` | 访问令牌 | 异常详情 / 关联原始报文（坏 XML 原样回查） |
| 管理 | POST | `/api/ticket/agent/errors/{id}/resolve` | 访问令牌 | 标记 RESOLVED / IGNORED |

### 关键机制

- **双向映射**：`XmlMessageCodec` 用独立 `XmlMapper`（与后台 JSON 的 ObjectMapper 隔离）；`@JacksonXmlProperty` 固化字段名与 header/body/ticket/session/seat 层级；未知字段容错（前向兼容），必填项在业务层显式校验。
- **收发留档**：落 `t_agent_message`（含 payload 原文、messageId、方向、类型、票号、订单号、场次短码、HTTP 状态、重试计数、最后错误）；索引用 `(ticket_no, id)` 支撑按票号回查。
- **出站时机**：票状态变更（出票/检票/退票/作废）在**所在事务提交后**（`AFTER_COMMIT`）才通知平台——回滚不通知；出站失败不反噬票务主流程，报文已落 PENDING 由定时任务补发。票源在场馆，出站含全部四类；入站仅受理平台侧的 CHECK/REFUND/VOID 状态同步。
- **防回声**：入站报文驱动的票状态变更带线程级来源标记，提交后不再回推平台，避免把平台发起的变更又通知回去。
- **重试**：每分钟扫描到期 `PENDING/RETRYING` 出站报文（`AgentMessageRetryJob`），指数退避（基数 30s，封顶 30min），默认最多 5 次；网络异常与 HTTP 非 2xx 均重试，**重试耗尽置 FAILED** 等待人工 `/retry`；平台回 2xx 但 ACK=`REJECTED` 视为终态拒收（不做无意义重试）。
- **入站幂等**：以平台 `messageId` 为幂等键（库内唯一约束兜底并发重复）；重复投递回 `DUPLICATE`，不重复处理。
- **异常清单**：落 `t_agent_parse_error`，分 `PARSE_ERROR`（结构坏，仍兜底抽取 messageId/ticketNo、原文保留）/ `VALIDATION_ERROR`（缺必填、类型非法）/ `BIZ_ERROR`（票不存在、非法状态流转等），可标记处理。
- 入站票状态同步**复用场馆既有票状态机**（SOLD→CHECKED / SOLD→REFUNDED / SOLD·CHECKED→VOID），非法流转与乐观锁冲突按业务失败进异常清单，不改底账。

### 配置（`evops.agent`）

| 配置 | 默认值 | 说明 |
|---|---|---|
| `enabled` / `EVOPS_AGENT_ENABLED` | true | 总开关；false 时业务仅落 PENDING 归档不投递，排期就绪后打开补发 |
| `endpoint` / `EVOPS_AGENT_ENDPOINT` | `http://localhost:8080/agent-stub/ticket` | 平台收票地址 |
| `venue-code` | VENUE | 场馆在平台侧的身份标识 |
| `connect-timeout-ms` / `read-timeout-ms` | 3000 / 5000 | HTTP 超时 |
| `max-retry` | 5 | 单条报文最大重试次数（不含首发） |
| `base-backoff-seconds` / `max-backoff-seconds` | 30 / 1800 | 退避基数与上限 |
| `retry-batch-size` | 100 | 定时重试每批上限 |

## 演出票附件与客服整批 ZIP 下载（ticket-2）

客服支持整批下载演出票附件：ZIP 打包、**单包最多 50 份票号**、中文文件名不乱码、包内带清单文件列出对应票号、**流式生成不占内存**。附件二进制存服务端受管目录，元数据落 `t_ticket_attachment`（Flyway V3）。

全部端点在 `/api/ticket/**` 下，**必须持访问令牌**（与其他票务接口一致的 JWT 鉴权）。

| 方法 | 路径 | 说明 |
|---|---|---|
| POST | `/api/ticket/tickets/{ticketNo}/attachments` | 为票号上传附件（multipart 字段 `file`，`remark` 可选），单文件 ≤20MB |
| GET | `/api/ticket/tickets/{ticketNo}/attachments` | 按票号列出全部有效附件 |
| GET | `/api/ticket/attachments/{id}/download` | 单个附件下载（中文文件名 RFC 5987 编码） |
| GET | `/api/ticket/attachments/zip?ticketNos=T001&ticketNos=T002` | **整批 ZIP 流式下载**，票号自动去重保序，单包 ≤50 |
| DELETE | `/api/ticket/attachments/{id}?reason=` | 逻辑删除（元数据与物理文件保留追溯） |

要点：

- **单包 50 份硬上限**：`evops.attachment.zip-max-tickets=50`，代码内再封顶 50（调小不允许调大）；超限在**打开响应流之前**拒绝，回 `200 + success=false` JSON，绝不产出半截 ZIP；超过请分批下载。
- **流式不占内存**：ZIP 直写响应输出流，逐附件 8KB 缓冲拷贝（`ZipOutputStream` UTF-8），整包不进内存、不落临时盘。采用请求线程内同步写出（不用 `StreamingResponseBody` 异步分派，规避 Shiro 过滤器链在异步再分派时无 SecurityManager 的兼容问题）。
- **中文不乱码**：ZIP 条目名以 UTF-8 写入（带 EFS 语言标志位），按 `票号/原始中文文件名` 组织目录，同目录重名自动加序号；包名/单文件名响应头同时给 ASCII `filename` 兜底与 `filename*=UTF-8''` 原文（RFC 5987）。
- **下载清单**：包内根目录固定带 `下载清单.txt`（UTF-8 带 BOM，Excel 直开不乱码），逐条列出 序号/票号/包内文件，并写明生成时间、操作人、请求号、文件数；无附件的票号、物理文件缺失的附件单列提示，不中断整包。
- **存储安全**：落盘名是服务端生成的 UUID（仅保留安全扩展名），原始中文文件名只存库、不参与路径拼接；路径规范化校验防穿越；先写 `.tmp` 再原子改名，半成品不会被下载读到。
- **元数据**：记录 SHA-256、大小、ContentType、操作人/请求号/业务时间；按票号查询走 `(ticket_no, id)` 索引。
- **鉴权**：无访问令牌/令牌失效一律 401；删除为逻辑删除（`deleted=id`，MyBatis-Plus `@TableLogic`），物理文件留存由运维按策略清理。
- 样本数据为 3 张样本票各挂一个中文文件名票根（`TSH001000000004`、`TSH001000000005`、`TSH002000000001`），可直接联调整批下载。

### 配置（`evops.attachment`）

| 配置 | 默认值 | 说明 |
|---|---|---|
| `storage-dir` / `EVOPS_ATTACHMENT_DIR` | `./data/attachments` | 附件受管存储目录（需纳入磁盘监控与备份） |
| `zip-max-tickets` / `EVOPS_ATTACHMENT_ZIP_MAX` | 50 | 单包票号上限（硬上限 50） |
| `max-upload-size` | 20MB | 单附件业务上限（容器 multipart 另限 20MB/请求 25MB） |

值班常见情况处置（401、超 50、乱码、文件缺失、下载中断、误删恢复等）见 [`docs/runbook/票附件批量下载-值班处置.md`](docs/runbook/票附件批量下载-值班处置.md)。

```bash
# 整批下载（注意重复传 ticketNos 参数；≤50 个）
curl -OJ "http://localhost:8080/api/ticket/attachments/zip?ticketNos=TSH001000000004&ticketNos=TSH002000000001" \
  -H 'Authorization: Bearer <accessToken>'

# 上传附件
curl -X POST "http://localhost:8080/api/ticket/tickets/TSH002000000001/attachments" \
  -H 'Authorization: Bearer <accessToken>' -F 'file=@/path/票根凭证.pdf'
```

## 检票关键节点通知场务（notify-1，Flyway V4）

观众检票（`SOLD→CHECKED`）事务提交后按事件自动通知当班场务：票/订单/场次/座位字段二次加工成模板变量，渲染成现场文案，经**站内信 + 邮件双通道**发送；逐通道发送记录入库可查，失败退避**自动重试 2 次**，模板改版只升版本、**不影响已发内容**，发送结果按批次/通道可统计。检票接口本身无任何变化。

| 方法 | 路径 | 说明 |
|---|---|---|
| GET | `/api/ticket/notify/inbox/messages` | 场务查本人站内信（按登录工号隔离），`readFlag` 过滤未读/已读 |
| GET | `/api/ticket/notify/inbox/unread-count` | 本人未读数 |
| POST | `/api/ticket/notify/inbox/messages/{id}/read` | 标记已读（幂等） |
| GET | `/api/ticket/notify/records` | 发送记录分页（`ticketNo/channel/status/dispatchId` 过滤） |
| GET | `/api/ticket/notify/records/{id}` | 记录详情：**渲染后标题/正文快照**、变量集、模板版本、回执、错误 |
| POST | `/api/ticket/notify/records/{id}/retry` | FAILED/RETRYING 手动立即重发 |
| GET | `/api/ticket/notify/stats?eventCode=&from=&to=` | 批次维度 + 通道维度发送统计 |
| GET/POST/PUT | `/api/ticket/notify/templates[/{id}]` | 模板维护；改标题/正文/事件码自动 `tpl_version+1` |
| GET/POST/PUT | `/api/ticket/notify/recipients[/{id}]` | 场务收件人维护（工号收站内信、邮箱收邮件，至少一个） |

要点：

- **按事件触发**：复用票生命周期事件 `TicketLifecycleEvent`，仅 `CHECK` 且在检票事务 **AFTER_COMMIT** 消费——回滚不通知；通知异常不外溢影响票务主流程。通知批次按 `(event_code, ticket_id)` 唯一，事件重放不重复通知。
- **数据二次加工**：`NotifyVarsBuilder` 把票号/订单号/演出/场次/场馆/区域排座/票价/检票时间/开演时间/检票人/备注汇成变量表，`TemplateRenderer` 替换 `${var}`（未提供变量替空串，不把占位原文发出去）。
- **双通道独立**：站内信写本地信箱（`record_id` 唯一约束保证重试不产生重复信）；邮件经 HTTP 投企业邮件出口网关，2xx+ACK OK 判成功。两通道开关独立，互不拖累。
- **发送记录即凭证**：渲染标题/正文/变量集在发送当次快照进 `t_notify_record`，记录当时模板版本；模板表文案版本独立列 `tpl_version`（与基类乐观锁 `version` 区分），改版对历史记录零影响。
- **失败重试 2 次**：首发失败置 `RETRYING`，退避 10s/20s（指数、上限 5min）由每分钟定时任务续投，重试 2 次仍败置 `FAILED`；批次据通道结果汇总 SUCCESS/PARTIAL/FAILED。收件人无邮箱/工号记 `SKIPPED`，不计故障。
- **邮件网关**：`evops.notify.email-endpoint` 指向出口网关；内置 `/mail-stub` 联调桩（不鉴权、内存邮箱、支持故障注入 `POST /mail-stub/_admin/fail-mode?times=N&status=500`），**上线必须把地址改为企业网关**。
- 样本数据：新增场务账号 `stage01`（周洋，口令同其他样本账号 `Venue@2026`）、收件人 2 名（场务+值班经理，双通道可达）、TICKET_CHECK 站内信/邮件模板各一套。

### 配置（`evops.notify`）

| 配置 | 默认值 | 说明 |
|---|---|---|
| `enabled` / `EVOPS_NOTIFY_ENABLED` | true | 通知总开关 |
| `inbox-enabled` / `email-enabled` | true / true | 两通道独立开关 |
| `email-endpoint` / `EVOPS_NOTIFY_EMAIL_ENDPOINT` | `http://localhost:8080/mail-stub/send` | **邮件出口网关（上线必改）** |
| `max-retry` | 2 | 首发失败后的自动重试次数（验收口径固定 2） |
| `base/max-backoff-seconds` | 10 / 300 | 指数退避基数与上限 |

验收（步骤+截图，非技术人员可读）：[`docs/acceptance/检票通知场务-验收报告.md`](docs/acceptance/检票通知场务-验收报告.md)；
值班处置：[`docs/runbook/检票通知场务-值班处置.md`](docs/runbook/检票通知场务-值班处置.md)。

## 场馆后台 JWT 双令牌认证（auth-1）

落实内部审计整改意见：访问令牌有效期短，刷新令牌轮换一次性使用，刷新后旧令牌立即失效，登出与改密都拉黑在用令牌，改密全端下线。

### 端点（前缀 `/api/auth`）

| 方法 | 路径 | 访问 | 说明 |
|---|---|---|---|
| POST | `/api/auth/login` | 匿名 | 账号密码换双令牌 |
| POST | `/api/auth/refresh` | 匿名 | 刷新令牌一次性轮换；**旧令牌重放触发家族连坐** |
| POST | `/api/auth/logout` | 访问令牌 | 拉黑当前 access 的 jti，可选撤销本设备 refresh |
| POST | `/api/auth/change-password` | 访问令牌 | 校验原密码；改密后全端下线，必须用新密码重新登录 |
| GET  | `/api/auth/me` | 访问令牌 | 当前账号信息（id/工号/姓名/场馆/角色） |

票务接口（`/api/ticket/**`）现在都需要访问令牌；健康检查 `/api/health` 与 login/refresh 保持匿名。

### 安全机制

- **访问令牌**：JWT(HS256) 自实现（JDK+Jackson，未引第三方库），有效期 **15 分钟**，带 `jti`、`tv`（密码版本）、`typ=access`。
- **刷新令牌**：不透明随机串（32 字节），有效期 **7 天**；明文只在响应里出现一次，库里只存 SHA-256 哈希。
- **一次性轮换**：每次 refresh 在库内条件更新 `ACTIVE→USED`（影响行数 0 即重放），再签发同一 `family_id` 新链节；旧 refresh 立刻失效。
- **重放连坐**：已 USED/REVOKED 的刷新令牌再次使用视为泄露，撤销同一 `family_id`（同一登录设备链）全部 ACTIVE 令牌；撤销走 REQUIRES_NEW 独立事务，**先落库再抛 401**，不随业务回滚。
- **登出**：当前 access 按 jti 入 `t_token_blacklist`（重复登出幂等），同时撤销本设备 refresh。
- **改密全端下线**：`token_version` 自增，所有旧 access 因 tv 不匹配立即失效；全部设备的 ACTIVE refresh 批量撤销；当前 access 一并拉黑。
- **口令存储**：PBKDF2-HMAC-SHA256（120000 轮、16 字节随机盐），用户名/密码错误统一文案防探测。
- **审计联动**：已登录请求的票务写操作，操作人自动取登录工号（`X-Operator-Id` 仍可显式覆盖）。
- **存证清理**：黑名单与过期刷新令牌由每日 03:17 的定时任务清除。

### 配置（`evops.auth`）

| 配置 | 默认值 | 说明 |
|---|---|---|
| `secret` / `EVOPS_AUTH_SECRET` | 演示固定值（必须替换） | HS256 密钥，≥32 字节；生产必须经环境变量注入 |
| `access-token-ttl-seconds` | 900（15 分钟） | 访问令牌有效期 |
| `refresh-token-ttl-seconds` | 604800（7 天） | 刷新令牌有效期 |
| `issuer` | `evops-venue-admin` | JWT `iss` |

### 演示账号与真实样本

首启自动播种（幂等，账号已存在则跳过）。样本取自**滨江大剧院**真实业务结构，非临时拼装：

- 3 个岗位账号，初始密码均为 `Venue@2026`（建议登录后立即改密）：

| 工号 | 姓名 | 角色 | 场馆 |
|---|---|---|---|
| `venue_admin` | 王芳 | ADMIN | 滨江大剧院 |
| `box_office01` | 李强 | STAFF（售票） | 滨江大剧院 |
| `ticket_check01` | 赵敏 | STAFF（检票） | 滨江大剧院 |

- 票务底账：26 个座位（一层池座 16 / 二层楼座 6 / VIP 包厢 4）、2 个场次；
  已结束场次 5 张订单 9 张票覆盖 **正常在售 / 检票入场 / 退票释放 / 整单作废** 完整业务链（带真实格式订单号、票号、请求号、反向流水追溯链）；在售票场次《天鹅湖·芭蕾经典》(SH002) 可现场继续售票检票，票号从样本计数连续分配。
- 票附件样本：`TSH001000000004`、`TSH001000000005`、`TSH002000000001` 各挂 1 个中文文件名票根，供客服整批 ZIP 下载联调（见 ticket-2）。

### 调用示例

```bash
# 登录
curl -X POST http://localhost:8080/api/auth/login -H 'Content-Type: application/json' \
  -d '{"username":"box_office01","password":"Venue@2026"}'

# 业务请求
curl http://localhost:8080/api/ticket/tickets/TSH001000000006 \
  -H 'Authorization: Bearer <accessToken>'

# 刷新（响应里的 refreshToken 下次轮换用，旧的立即失效）
curl -X POST http://localhost:8080/api/auth/refresh -H 'Content-Type: application/json' \
  -d '{"refreshToken":"<refreshToken>"}'

# 登出（可带 refreshToken 一并撤销本设备）
curl -X POST http://localhost:8080/api/auth/logout -H 'Authorization: Bearer <accessToken>' \
  -H 'Content-Type: application/json' -d '{"refreshToken":"<refreshToken>"}'

# 改密（全端下线，随后用新密码重新登录）
curl -X POST http://localhost:8080/api/auth/change-password \
  -H 'Authorization: Bearer <accessToken>' -H 'Content-Type: application/json' \
  -d '{"oldPassword":"Venue@2026","newPassword":"新密码8位以上"}'
```



